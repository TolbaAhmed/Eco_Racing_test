# ECO-test
there is 2 folders one for the master MC and the other for the slave MC
I'm using ATMEGA32 microcontroller
the only library that I have included is delay.h otherwise they all are my drivers
